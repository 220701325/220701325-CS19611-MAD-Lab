package com.alaishat.mohammad.clean.docdoc.presentation.feature.auth.register

import androidx.compose.runtime.Composable
import com.alaishat.mohammad.clean.docdoc.presentation.feature.auth.AuthEvent

/**
 * Created by Mohammad Al-Aishat on Apr/13/2025.
 * Clean DocDoc Project.
 */
//@Composable
//fun AuthEventHandler(eventState: AuthEvent<>) {
//
//}
