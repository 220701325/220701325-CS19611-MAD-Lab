package com.alaishat.mohammad.clean.docdoc.data.model

/**
 * Created by Mohammad Al-Aishat on Apr/13/2025.
 * Clean DocDoc Project.
 */
data class LoginRequest(val email: String, val password: String)
