package com.alaishat.mohammad.clean.docdoc.presentation.feature.book_appointment

/**
 * Created by Mohammad Al-Aishat on Apr/18/2025.
 * Clean DocDoc Project.
 */
data class BookAppointmentUIState(
    val isLoading: Boolean = false,
    // todo: selectedDate
)
